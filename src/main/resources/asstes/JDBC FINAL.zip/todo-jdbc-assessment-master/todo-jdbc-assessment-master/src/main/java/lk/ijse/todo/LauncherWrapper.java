package lk.ijse.todo;

/*
    @author DanujaV
    @created 11/7/23 - 12:11 AM   
*/

public class LauncherWrapper {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
