package lk.ijse.Library.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lk.ijse.Library.dto.DonationDto;
import lk.ijse.Library.dto.SupplierDto;
import lk.ijse.Library.model.DonationModel;
import lk.ijse.Library.model.SupplierModel;

import java.io.IOException;
import java.sql.SQLException;

public class DonationFormController {

    @FXML
    private AnchorPane pane;

    @FXML
    private TableColumn<?, ?> colAddress;

    @FXML
    private TableColumn<?, ?> colContact;

    @FXML
    private TableColumn<?, ?> colMonetaryAmount;

    @FXML
    private TableColumn<?, ?> colName;

    @FXML
    private TableColumn<?, ?> cold_id;

    @FXML
    private TextField txtAddress;

    @FXML
    private TextField txtConNum;

    @FXML
    private TextField txtMonetaryAmount;

    @FXML
    private TextField txtName;

    @FXML
    private TextField txtd_id;

    @FXML
    void ADDOnAction(ActionEvent event) {

        String d_id = txtd_id.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();
        int tel = Integer.parseInt(txtConNum.getText());
        int monetary_amount= Integer.parseInt(txtMonetaryAmount.getText());



        var dto = new DonationDto(d_id, name, address,tel ,monetary_amount);

        var model = new DonationModel();

        try {
            boolean isSaved = model.saveDonation(dto);
            if (isSaved) {
                new Alert(Alert.AlertType.CONFIRMATION, "Donation saved!").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }

    }

    @FXML
    void BookOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"donation_form.fxml","donation");
    }

    @FXML
    void BookOrdersOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"book_orders_form.fxml","book_order");
    }

    @FXML
    void BookSeachsOnAction(ActionEvent event) {

    }

    @FXML
    void CLEAREOnAction(ActionEvent event) {

        clearFields();
    }

    @FXML
    void DELETEOnAction(ActionEvent event) {

        String d_id = txtd_id.getText();

        var model = new DonationModel();

        try {
            boolean isSaved = model.deleteDonation(d_id);
            if (isSaved) {
                new Alert(Alert.AlertType.CONFIRMATION, "Donation Delete!").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }

    @FXML
    void DonationOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"donation_form.fxml","donation");
    }

    @FXML
    void EmployeOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"employe_form.fxml","employe");
    }

    @FXML
    void IncomeOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"income.fxml","income");
    }

    @FXML
    void LoginHistoryOnAction(ActionEvent event) {

    }

    @FXML
    void LogoutOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"login_form.fxml","login");
    }

    @FXML
    void MemberOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"member_form.fxml","member");
    }

    @FXML
    void SalaryOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"salary_form.fxml","salary");
    }

    @FXML
    void SupplierOnAction(ActionEvent event) throws IOException {
        navigate.navigate(pane,"supplier_form.fxml","supplier");
    }

    @FXML
    void UPDATEOnAction(ActionEvent event) {

        String d_id = txtd_id.getText();
        String name = txtName.getText();
        String address = txtAddress.getText();
        int tel = Integer.parseInt(txtConNum.getText());
        int monetary_amount= Integer.parseInt(txtMonetaryAmount.getText());



        var dto = new DonationDto(d_id, name, address,tel ,monetary_amount);

        var model = new DonationModel();

        try {
            boolean isSaved = model.updateDonation(dto);
            if (isSaved) {
                new Alert(Alert.AlertType.CONFIRMATION, "Donation Update!").show();
                clearFields();
            }
        } catch (SQLException e) {
            new Alert(Alert.AlertType.ERROR, e.getMessage()).show();
        }
    }
    @FXML
    private TableView<?> tblDonation;

    void clearFields() {
        txtd_id.setText("");
        txtName.setText("");
        txtAddress.setText("");
        txtConNum.setText("");
        txtMonetaryAmount.setText("");
    }
}
