package lk.ijse.Library.dto.tm;

public class DonationTm {
}
