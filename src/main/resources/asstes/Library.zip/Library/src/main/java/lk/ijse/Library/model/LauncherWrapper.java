package lk.ijse.Library.model;

public class LauncherWrapper {
    public static void main(String[] args) {
        Launcher.main(args);
    }
}
